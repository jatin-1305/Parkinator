import random
import firebase as fb

firebase_basic_url = "https://parkinator-db-default-rtdb.firebaseio.com/.json"
firebase_visitor_url = "https://parkinator-db-default-rtdb.firebaseio.com/Visitors.json"
firebase_vurl = "https://parkinator-db-default-rtdb.firebaseio.com/Visitors/"

menu = {
    "Faculty":
        {
            '2 Tyre': ['A1', 'A2', 'A3', 'A4', 'A5', 'B1', 'B2', 'B3', 'B4', 'B5'],
            '4 Tyre': ['AA1', 'AA2', 'AA3', 'AA4', 'AA5', 'BB1', 'BB2', 'BB3', 'BB4', 'BB5']
        },
    "Student":
        {
            '2 Tyre': ['C1', 'C2', 'C3', 'C4', 'C5', 'D1', 'D2', 'D3', 'D4', 'D5'],
            '4 Tyre': ['CC1', 'CC2', 'CC3', 'CC4', 'CC5', 'DD1', 'DD2', 'DD3', 'DD4', 'DD5']
        },
    "Visitor":
        {
            '2 Tyre': ['E1', 'E2', 'E3', 'E4', 'E5'],
            '4 Tyre': ['EE1', 'EE2', 'EE3', 'EE4', 'EE5']
        }
}


def fb_fetch_data():
    zz = fb.get_data(firebase_visitor_url)
    return zz


def slot_gen_func(vehicle_type):
    slots_set = []
    slots = for_id_slots_func()
    pType = "Visitor"
    a = menu[pType]
    name = str(vehicle_type) + ' Tyre'
    slots_list = a[name]
    slot = slots_list[0]
    while (slot in slots):
        slot_index = random.randint(0, len(slots_list))
        slot = slots_list[slot_index]
        if (slot not in slots_set):
            slots_set.append(slot)
        elif (len(slots_list) == len(slots_set)):
            return 'No slots available'
    return slot


def fb_insert_visitor_data(mobile_number, name, vehicle_type):
    allotment = slot_gen_func(vehicle_type)
    json_data = {mobile_number: {'name': name, 'allotment': allotment, 'vehicle_type': vehicle_type}}
    fb.create_patch(firebase_visitor_url, json_data)
    return allotment


filled_slots = []


def for_id_slots_func():
    details = fb.get_data()
    keys = [*details.keys()]
    for mobile_number in keys:
        data_url = firebase_vurl + mobile_number + "/allotment.json"
        person_slot = fb.get_data(data_url)
        filled_slots.append(person_slot)
    return filled_slots


def fb_delete(mobile_number):
    delete_url = firebase_vurl + mobile_number + ".json"
    fb.delete_data(delete_url)


def fb_get_details(mobile_number):
    data_url = firebase_vurl + mobile_number + ".json"
    return fb.get_data(data_url)


def fb_visitor_checkout(mobile_number):
    fb_delete(mobile_number)
