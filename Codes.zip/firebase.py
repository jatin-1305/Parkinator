import requests as rq
import json

firebase_url = "https://parkinator-db-default-rtdb.firebaseio.com/.json"


def create_patch(patch_url,json_data):
    rs = rq.patch(url=patch_url,json=json_data)
    return rs

def get_data(durl=firebase_url):
    rs = rq.get(url=durl)
    z = rs.json()
    return z

def post_data(durl, json_data):
    rs = rq.post(url=durl,json=json_data)
    return rs

def put_data(data_url,json_data):
    rs = rq.put(url=data_url,json=json_data)
    return rs

def delete_data(delete_url):
    rs = rq.delete(delete_url)
    return rs