import random
import firebase as fb

firebase_basic_url = "https://parkinator-db-default-rtdb.firebaseio.com/.json"
firebase_member_url = "https://parkinator-db-default-rtdb.firebaseio.com/Members.json"
firebase_murl = "https://parkinator-db-default-rtdb.firebaseio.com/Members/"

menu = {
    "Faculty":
        {
            '2 Tyre': ['A1', 'A2', 'A3', 'A4', 'A5', 'B1', 'B2', 'B3', 'B4', 'B5'],
            '4 Tyre': ['AA1', 'AA2', 'AA3', 'AA4', 'AA5', 'BB1', 'BB2', 'BB3', 'BB4', 'BB5']
        },
    "Student":
        {
            '2 Tyre': ['C1', 'C2', 'C3', 'C4', 'C5', 'D1', 'D2', 'D3', 'D4', 'D5'],
            '4 Tyre': ['CC1', 'CC2', 'CC3', 'CC4', 'CC5', 'DD1', 'DD2', 'DD3', 'DD4', 'DD5']
        },
    "Visitor":
        {
            '2 Tyre': ['E1', 'E2', 'E3', 'E4', 'E5'],
            '4 Tyre': ['EE1', 'EE2', 'EE3', 'EE4', 'EE5']
        }
}

def present(id):
    details = fb.get_data()
    keys = [*details.keys()]
    if (id in keys):
        return True
    return False

def fb_fetch_data():
    return fb.get_data(firebase_member_url)


def fb_insert_member_data(id, password, name, email, person_type):
    # if (present(id)):
    #     return False
    # else :
    json_data = {id: {'password': password, 'name': name, 'allotment': '?', 'email': email, 'vehicle_type': -1,
                          'person_type': person_type}}
    fb.create_patch(firebase_member_url, json_data)



def fb_check(id, password):
    # details = fb.get_data()
    # keys = [*details.keys()]
    # if(id in keys):
    data_url = firebase_murl + id + "/password.json"
    new_password = fb.get_data(data_url)
    if (new_password == password):
        return True
    return False


def fb_delete(id):
    delete_url = firebase_murl + id + ".json"
    fb.delete_data(delete_url)


def fb_update_password(id, new_password):
    # if (present(id)):
    data_url = firebase_murl + id + "/password.json"
    fb.put_data(data_url, new_password)


def fb_email_OTP(id):
    data_url = firebase_murl + id + "/email.json"
    email = fb.get_data(data_url)
    return email


def fb_get_details(id):
    data_url = firebase_murl + id + ".json"
    s = fb.get_data(data_url)
    return s


def check_slot_person_func(id):
    data_url = firebase_murl + id + "/allotment.json"
    slot = fb.get_data(data_url)
    if (slot == '?'):
        return True
    return False

def slot_person_func(id):
    data_url = firebase_murl + id + "/allotment.json"
    slot = fb.get_data(data_url)
    return slot



filled_slots = []


def for_id_slots_func():
    details = fb.get_data(firebase_member_url)
    keys = [*details.keys()]
    for id in keys:
        data_url = firebase_murl + id + "/allotment.json"
        person_slot = fb.get_data(data_url)
        filled_slots.append(person_slot)
    return filled_slots


def person_type_func(id):
    data_url = firebase_murl + id + "/person_type.json"
    Person = fb.get_data(data_url)
    a = "Student"
    if (Person == 1):
        a = "Faculty"
    elif (Person == 2):
        a = "Visitor"
    return a


def update_slot_func(id, slot):
    data_url = firebase_murl + id + "/allotment.json"
    fb.put_data(data_url, slot)


def update_vehicle_func(id, vehicle_type):
    data_url = firebase_murl + id + "/vehicle_type.json"
    fb.put_data(data_url, vehicle_type)


def fb_checkin(id, vehicle_type):
    slots_set = []
    if (check_slot_person_func(id)):
        slots = for_id_slots_func()
        pType = person_type_func(id)
        a = menu[pType]
        name = str(vehicle_type) + ' Tyre'
        slots_list = a[name]
        slot = slots_list[0]
        while (slot in slots):
            slot_index = random.randint(0, len(slots_list))
            slot = slots_list[slot_index]
            if (slot not in slots_set):
                slots_set.append(slot)
            elif (len(slots_list) == len(slots_set)):
                return 'No slots available'
        update_slot_func(id, slot)
        update_vehicle_func(id, vehicle_type)
        return 'Your slot is '+slot
    else:
        ans = 'You have already booked\nslot: '+slot_person_func(id)
        return ans
    return False


def fb_checkout(id):

    update_slot_func(id,'?')
    update_vehicle_func(id,-1)
    return "checkout"

